package com.example.springboot.ejerciciofinal.aplicacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ejerciciofinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ejerciciofinalApplication.class, args);
	}

}
