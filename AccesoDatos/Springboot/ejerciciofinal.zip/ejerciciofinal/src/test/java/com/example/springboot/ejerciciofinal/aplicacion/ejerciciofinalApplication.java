package com.example.springboot.ejerciciofinal.aplicacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ejerciciofinalTests {

	@Test
	void contextLoads() {
	}

}
